<!-- About Section -->
<section id="about" class="about-section section-padding">
    <div class="container">
        <div class="row align-items-center g-5">
            <div class="col-lg-6">
                <div class="about-content">
                    <h2 class="section-title"><?php echo $about['title']; ?></h2>
                    <p class="section-subtitle text-primary"><?php echo $about['subtitle']; ?></p>
                    <?php 
                    $paragraphs = explode("\\n\\n", $about['content']);
                    foreach ($paragraphs as $paragraph): 
                    ?>
                    <p class="lead"><?php echo $paragraph; ?></p>
                    <?php endforeach; ?>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="about-image">
                    <img src="https://assets2.ser.vi/brand/alluseuvenue/feature_image/d-angelos-venue.png" alt="D'Angelo's Pizza Gun Hill Road - Best Pizza Near Me Bronx NY - D'Angelo's Pizzeria" class="img-fluid rounded" width="800" height="600" loading="lazy">
                </div>
            </div>
        </div>
        
        <!-- Features -->
        <div class="row mt-5 g-4">
            <?php foreach ($config['features'] as $feature): ?>
            <div class="col-md-4">
                <div class="feature-card text-center">
                    <div class="feature-icon">
                        <i class="bi bi-<?php echo $feature['icon']; ?>"></i>
                    </div>
                    <h4 class="feature-title"><?php echo $feature['title']; ?></h4>
                    <p class="feature-description"><?php echo $feature['description']; ?></p>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

